# RoadFighter
Hardware implementation in FPGA of an arcade game (SpaceInvaders) in 8x8 matrix.

This implementation was done in the second semester of 2019. Here is the Quartus Prime Project with all components needed for the architecture designed. 
Video: https://www.youtube.com/watch?v=LsWkq3Zw1AQ
